(function() {
    // --- Safe Fallback Data ---
    const SAFE_DATA = {
        isOffline: true,
        banner: { title: "Welcome Doctor", cover: "", link: "#" },
        newsList: [{ title: "Connection System Initializing...", date: "...", link: "#" }]
    };

    function requestData() {
        // We look for the containers
        const oldNews = document.querySelector('.scrollarea');
        const oldHighlights = document.querySelector('.mantine-Carousel-container');

        // If they aren't there yet, wait a bit
        if (!oldNews || !oldHighlights) {
            setTimeout(requestData, 200);
            return;
        }

        // --- THE REACT FIX ---
        // Clone to disconnect from React
        const newsContainer = oldNews.cloneNode(true);
        oldNews.parentNode.replaceChild(newsContainer, oldNews);

        const highlightsContainer = oldHighlights.cloneNode(true);
        oldHighlights.parentNode.replaceChild(highlightsContainer, oldHighlights);
        // ---------------------

        // Set Loading State
        newsContainer.innerHTML = `<div style="padding:20px; color:#aaa; text-align:center; font-family:monospace;">Connecting to Rhodes Network...</div>`;

        // Check availability
        if (!chrome || !chrome.runtime || !chrome.runtime.sendMessage) {
            renderData(SAFE_DATA, newsContainer, highlightsContainer);
            return;
        }

        // Send Message to Background Script
        try {
            chrome.runtime.sendMessage({ type: 'FETCH_NEWS' }, (response) => {
                if (chrome.runtime.lastError) {
                    console.warn("Rhodes Patch: Background link error.");
                    renderData(SAFE_DATA, newsContainer, highlightsContainer);
                    return;
                }
                
                if (response) {
                    renderData(response, newsContainer, highlightsContainer);
                } else {
                    renderData(SAFE_DATA, newsContainer, highlightsContainer);
                }
            });
        } catch (e) {
            renderData(SAFE_DATA, newsContainer, highlightsContainer);
        }
    }

    // --- CAROUSEL LOGIC ---
    function startCarousel(container, items) {
        if (!items || items.length === 0) return;

        let currentIndex = 0;
        
        container.innerHTML = '';
        container.style.position = 'relative';
        container.style.overflow = 'hidden';

        const banner = document.createElement('div');
        banner.style.cssText = `
            width: 100%; height: 100%; 
            background-size: cover; background-position: center; 
            transition: background-image 0.5s ease-in-out;
            display: flex; align-items: flex-end; cursor: pointer;
        `;

        const overlay = document.createElement('div');
        overlay.style.cssText = "width:100%; padding:20px; background:linear-gradient(to top, rgba(0,0,0,0.9), transparent);";
        
        const subtitle = document.createElement('div');
        subtitle.style.cssText = "color:#29B6F6; font-size:0.8rem; font-weight:bold; letter-spacing:1px; margin-bottom:4px; font-family:monospace;";
        
        const title = document.createElement('h2');
        title.style.cssText = "color:#fff; margin:0; font-family:'Oswald',sans-serif; font-size:1.6rem; text-shadow: 0 2px 4px black; line-height:1.2;";

        overlay.appendChild(subtitle);
        overlay.appendChild(title);
        banner.appendChild(overlay);
        container.appendChild(banner);

        const updateSlide = () => {
            const item = items[currentIndex];
            
            const imgCheck = new Image();
            imgCheck.src = item.cover;
            imgCheck.onload = () => { banner.style.backgroundImage = `url('${item.cover}')`; };
            imgCheck.onerror = () => { banner.style.backgroundImage = `url('https://web.hycdn.cn/arknights/official/assets/images/bg.jpg')`; };
            
            subtitle.innerText = `// ${item.subtitle || 'EVENT'}`;
            title.innerText = item.title;
            banner.onclick = () => window.open(item.link, '_blank');
        };

        updateSlide();

        if (items.length > 1) {
            setInterval(() => {
                currentIndex = (currentIndex + 1) % items.length;
                updateSlide();
            }, 6000);
        }
    }

    function renderData(data, newsContainer, highlightsContainer) {
        if (!newsContainer || !highlightsContainer) return;

        newsContainer.innerHTML = '';
        
        if (data.isOffline) {
            const badge = document.createElement('div');
            badge.textContent = '⚠ OFFLINE BACKUP';
            badge.style.cssText = "background:#ffc107; color:black; font-weight:bold; padding:4px; text-align:center; font-size:0.7rem; margin-bottom:10px; border-radius: 2px; font-family:sans-serif;";
            newsContainer.appendChild(badge);
        }

        const listItems = data.newsList || [];
        
        listItems.forEach(item => {
            const card = document.createElement('div');
            
            // UPDATED OPACITY HERE: rgba(30, 30, 30, 0.67)
            card.style.cssText = `background:rgba(30, 30, 30, 0.67); border-left:4px solid #fff; padding:12px; margin-bottom:6px; cursor:pointer; transition: 0.2s;`;
            
            // Hover makes it slightly brighter (0.9) for interaction feedback
            card.onmouseenter = () => card.style.background = 'rgba(50, 50, 50, 0.9)';
            
            // Reset to 0.67 on leave
            card.onmouseleave = () => card.style.background = 'rgba(30, 30, 30, 0.67)';

            // Text colors
            const dateColor = (item.date.includes("LIVE") || item.date.includes("UPCOMING")) ? "#29B6F6" : "#aaa";

            card.innerHTML = `
                <div style="color:#fff; font-size:0.9rem; font-weight:500; line-height:1.2; font-family:sans-serif;">${item.title}</div>
                <div style="color:${dateColor}; font-size:0.7rem; font-family:monospace; margin-top:4px;">${item.date}</div>
            `;
            
            card.onclick = () => window.open(item.link, '_blank');
            newsContainer.appendChild(card);
        });

        // Start Carousel
        startCarousel(highlightsContainer, data.highlights);
    }

    setTimeout(requestData, 500);
})();